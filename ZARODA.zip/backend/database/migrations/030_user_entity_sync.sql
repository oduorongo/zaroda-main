-- ============================================================================
-- 030_user_entity_sync.sql
-- Bring the users table in line with the NestJS User entity. Some columns the
-- app reads (stream_id, stream_name, id_number, subjects, email_verified,
-- must_change_password) were never added by earlier migrations, causing
-- "column User.stream_id does not exist" on login/signup. All idempotent.
-- ============================================================================

ALTER TABLE users ADD COLUMN IF NOT EXISTS stream_id            UUID;
ALTER TABLE users ADD COLUMN IF NOT EXISTS stream_name          VARCHAR(150);
ALTER TABLE users ADD COLUMN IF NOT EXISTS id_number            VARCHAR(30);
ALTER TABLE users ADD COLUMN IF NOT EXISTS tsc_number           VARCHAR(30);
ALTER TABLE users ADD COLUMN IF NOT EXISTS subjects             TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_active            BOOLEAN NOT NULL DEFAULT true;
ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified       BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at        TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_users_stream_id ON users(stream_id);

-- Signup is KNEC-code based and does not set a subdomain, but migration 001 made
-- tenants.subdomain NOT NULL. Drop that constraint so signup can create a tenant.
-- (Backfill any existing nulls first in case the column already has the constraint.)
ALTER TABLE tenants ALTER COLUMN subdomain DROP NOT NULL;

-- The app sets subscription_tier='trial', but migration 001's CHECK only allowed
-- ('free','primary','senior'). Drop the restrictive check so app values are accepted.
ALTER TABLE tenants DROP CONSTRAINT IF EXISTS tenants_subscription_tier_check;

-- Sync the schools table with the School entity. Migration 001 was missing several
-- columns the app writes (mpesa_paybill, zone, location ids) and marked school_type/
-- category/gender_type NOT NULL even though signup doesn't set them.
ALTER TABLE schools ADD COLUMN IF NOT EXISTS mpesa_paybill    VARCHAR(20);
ALTER TABLE schools ADD COLUMN IF NOT EXISTS zone             VARCHAR(150);
ALTER TABLE schools ADD COLUMN IF NOT EXISTS ke_county_id     SMALLINT;
ALTER TABLE schools ADD COLUMN IF NOT EXISTS ke_sub_county_id SMALLINT;
ALTER TABLE schools ADD COLUMN IF NOT EXISTS ke_zone_id       SMALLINT;
ALTER TABLE schools ALTER COLUMN school_type DROP NOT NULL;
ALTER TABLE schools ALTER COLUMN category    DROP NOT NULL;
ALTER TABLE schools ALTER COLUMN gender_type DROP NOT NULL;

-- Sync the streams table with the Stream entity. Migration 001 was missing the
-- class-teacher and learners-count columns the app reads/writes when creating a class.
ALTER TABLE streams ADD COLUMN IF NOT EXISTS class_teacher_id   UUID;
ALTER TABLE streams ADD COLUMN IF NOT EXISTS class_teacher_name VARCHAR(150);
ALTER TABLE streams ADD COLUMN IF NOT EXISTS learners_count     INTEGER NOT NULL DEFAULT 0;
-- The app does not set term on insert; keep its default but ensure no insert is blocked.
ALTER TABLE streams ALTER COLUMN term DROP NOT NULL;

-- The learners insert identifies a learner by tenant_id + stream_id and does not send
-- school_id or academic_year, but migration 003 marked both NOT NULL. Relax them.
ALTER TABLE learners ALTER COLUMN school_id     DROP NOT NULL;
ALTER TABLE learners ALTER COLUMN academic_year DROP NOT NULL;

-- The academic dashboard reads SUM(amount_paid) FROM invoices, but migration 001's
-- invoices table has no amount_paid column. Add it (read-only stat; defaults to 0).
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS amount_paid NUMERIC(10,2) NOT NULL DEFAULT 0;

-- The exams feature: migration 003 created `exams` first (so 013's richer version was
-- skipped by IF NOT EXISTS). The app needs max_score, doesn't send school_id/academic_year,
-- and uses status='scheduled' + free-form exam_type/term that 003's CHECKs reject. Sync it.
ALTER TABLE exams ADD COLUMN IF NOT EXISTS max_score INT DEFAULT 100;
ALTER TABLE exams ALTER COLUMN school_id     DROP NOT NULL;
ALTER TABLE exams ALTER COLUMN academic_year DROP NOT NULL;
ALTER TABLE exams DROP CONSTRAINT IF EXISTS exams_exam_type_check;
ALTER TABLE exams DROP CONSTRAINT IF EXISTS exams_term_check;
ALTER TABLE exams DROP CONSTRAINT IF EXISTS exams_status_check;
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='exams' AND column_name='term' AND is_nullable='NO') THEN
    ALTER TABLE exams ALTER COLUMN term DROP NOT NULL;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='exams' AND column_name='exam_type' AND is_nullable='NO') THEN
    ALTER TABLE exams ALTER COLUMN exam_type DROP NOT NULL;
  END IF;
END $$;

-- Simple fee structure storage matching the finance UI (HOI/bursar set these).
-- The richer fee_structures table from 004 stays for future use; this backs the
-- current Fee Structures page directly.
CREATE TABLE IF NOT EXISTS fee_items (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     UUID NOT NULL,
  school_id     UUID,
  name          VARCHAR(200) NOT NULL,
  grade_level   VARCHAR(40),
  term          VARCHAR(20),
  academic_year VARCHAR(20),
  category      VARCHAR(40)  DEFAULT 'tuition',
  amount        NUMERIC(12,2) NOT NULL DEFAULT 0,
  is_mandatory  BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_fee_items_tenant ON fee_items(tenant_id);

-- The platform owner (super_admin) belongs to no single school, so users.tenant_id
-- must allow NULL for that one account. School users still always have a tenant.
ALTER TABLE users ALTER COLUMN tenant_id DROP NOT NULL;
